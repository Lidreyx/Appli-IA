package com.example.iappli;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Url;
import okhttp3.RequestBody;

public interface AzureApiService {
    @POST
    Call<Object> analyzeImage(
            @Url String url,                     // URL spécifique à l'endpoint
            @Header("7b291363bd8f437dbfba953fe21ccbc5") String apiKey, // Clé API Azure
            @Header("Content-Type") String contentType,         // Type de contenu
            @Body RequestBody requestBody        // Corps de la requête
    );
}