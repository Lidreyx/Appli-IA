
package com.example.iappli;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import com.example.iappli.BuildConfig;

int versionCode = BuildConfig.VERSION_CODE;
String versionName = BuildConfig.VERSION_NAME;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int CAMERA_REQUEST_CODE = 100;
    private Uri photoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnTakePhoto = findViewById(R.id.btn_take_photo);
        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    openCamera();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
    private void openCamera() throws IOException {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();

            if (photoFile != null) {
                photoUri = FileProvider.getUriForFile(
                        this,
                        BuildConfig.APPLICATION_ID + ".fileprovider",
                        photoFile
                );
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); // Permission temporaire
                startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
            }
        }
    }
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String imageFileName = "JPEG" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            processCapturedPhoto(photoUri);
        }
    }
    private void processCapturedPhoto(Uri photoUri) {
        try {
            File file = new File(photoUri.getPath());

            RequestBody requestBody = RequestBody.create(
                    MediaType.parse("application/octet-stream"),
                    file
            );

            executeAzureApiCall(requestBody);

        } catch (Exception e) {
            Log.e(TAG, "Erreur lors du traitement de la photo", e);
        }
    }

    private void executeAzureApiCall(RequestBody requestBody) {
        AzureApiService azureApiService = RetrofitClient.getRetrofitInstance().create(AzureApiService.class);

        Call<Object> call = azureApiService.analyzeImage(
                "vision/v3.2/analyze?visualFeatures=Categories,Description,Color",
                "7b291363bd8f437dbfba953fe21ccbc5", // Remplacez par votre clé API Azure
                "application/octet-stream",
                requestBody
        );

        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d(TAG, "Réponse de l'API : " + response.body().toString());
                } else {
                    Log.e(TAG, "Erreur dans la réponse : " + response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e(TAG, "Erreur réseau ou serveur", t);
            }
        });
    }
}